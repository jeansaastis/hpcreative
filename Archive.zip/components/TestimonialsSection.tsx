// components/TestimonialsSection.tsx
'use client'

import Image from 'next/image'

type Testimonial = {
  _id?: string
  author?: string
  role?: string
  quote?: string
  portrait?: {asset?: {url?: string}}
}

export default function TestimonialsSection({testimonials}: {testimonials: Testimonial[]}) {
  if (!Array.isArray(testimonials) || testimonials.length === 0) return null

  return (
    <section className="w-full py-5 px-6 bg-white">
      <h2 className="font-display font-bold mb-6 text-5xl">HP:sta sanottua</h2>

      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {testimonials.map((t, idx) => {
          if (!t?.quote) return null

          return (
            <li key={t._id || idx}>
              <article className="relative bg-white text-black rounded-[.5rem] p-5 md:p-6 min-h-[180px] flex flex-col border border-gray-200">
                {/* Portrait (optional) */}
                {t.portrait?.asset?.url && (
                  <div className="absolute top-4 left-4 h-10 w-10 rounded-full overflow-hidden ring-1 ring-gray-300">
                    <Image
                      src={t.portrait.asset.url}
                      alt={t.author ? `${t.author} portrait` : 'Portrait'}
                      fill
                      sizes="40px"
                      className="object-cover"
                    />
                  </div>
                )}

                {/* Quote */}
                <blockquote className="relative text-base md:text-lg font-light leading-relaxed mt-6">
                  {t.quote}
                </blockquote>

                {/* Author / role */}
                <div className="mt-4">
                  {t.author && <div className="font-semibold">{t.author}</div>}
                  {t.role && <div className="text-sm text-gray-500">{t.role}</div>}
                </div>
              </article>
            </li>
          )
        })}
      </ul>
    </section>
  )
}
