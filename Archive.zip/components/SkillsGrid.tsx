'use client'

import React, {useEffect, useMemo, useRef, useState} from 'react'

const PALETTE = ['#11171C', '#020202', '#1B2730', '#048A81', '#1B2730']

// helpers
function hexToHsl(hex: string) {
  hex = hex.replace(/^#/, '')
  if (hex.length === 3)
    hex = hex
      .split('')
      .map((c) => c + c)
      .join('')
  const int = parseInt(hex, 16)
  const r = ((int >> 16) & 255) / 255
  const g = ((int >> 8) & 255) / 255
  const b = (int & 255) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  let h = 0,
    s = 0
  const l = (max + min) / 2
  const d = max - min
  if (d !== 0) {
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0)
        break
      case g:
        h = (b - r) / d + 2
        break
      default:
        h = (r - g) / d + 4
    }
    h *= 60
  }
  return {h, s: s * 100, l: l * 100}
}
const hslToCss = (h: number, s: number, l: number) =>
  `hsl(${Math.round(h)} ${Math.round(s)}% ${Math.round(l)}%)`
const jitter = (v: number, amt: number) =>
  Math.max(0, Math.min(100, v + (Math.random() * 2 - 1) * amt))

type Skill = {title: string}
type Circle = {
  x: number
  y: number
  size: number
  color: string
  blur: number
  opacity: number
  dur: number
  delay: number
  dx: number
  dy: number
  dx2: number
  dy2: number
}

export default function SkillsGrid({skills}: {skills: Skill[]}) {
  // motion preference
  const prefersReduced = useMemo(
    () =>
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
    [],
  )

  // crypto RNG
  const rnd = useMemo(() => {
    const buf = new Uint32Array(1)
    return () => {
      try {
        crypto.getRandomValues(buf)
        return buf[0] / 0xffffffff
      } catch {
        return Math.random()
      }
    }
  }, [])
  const r = (min: number, max: number) => min + (max - min) * rnd()

  // circles per card
  const [circles, setCircles] = useState<Circle[][] | null>(null)

  useEffect(() => {
    const next: Circle[][] = skills.map(() => {
      const count = Math.floor(r(3, 6))
      return Array.from({length: count}).map(() => {
        const base = PALETTE[Math.floor(r(0, PALETTE.length))]
        const {h, s, l} = hexToHsl(base)
        const dx = r(-60, 90)
        const dy = r(-45, 70)
        return {
          x: r(10, 90),
          y: r(10, 85),
          size: r(70, 160),
          color: hslToCss(h, jitter(s, 6), jitter(l, 8)),
          blur: r(10, 26),
          opacity: r(0.22, 0.4),
          dur: r(8, 12),
          delay: r(0, 2.5),
          dx,
          dy,
          dx2: -0.6 * dx,
          dy2: -0.6 * dy,
        }
      })
    })
    setCircles(next)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [skills.length])

  // --- Scroll reveal (Anime.js v4) ---
  const gridRef = useRef<HTMLUListElement | null>(null)
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]) // one ref per card

  useEffect(() => {
    if (prefersReduced) return
    const grid = gridRef.current
    if (!grid) return

    // set initial hidden state
    cardRefs.current.forEach((el) => {
      if (!el) return
      el.style.opacity = '0'
      el.style.transform = 'translateY(16px)'
      el.style.willChange = 'opacity, transform'
    })

    let done = false
    let cleanupIO: (() => void) | null = null
    let inst: any

    const setup = async () => {
      const {animate, stagger} = await import('animejs')

      const io = new IntersectionObserver(
        (entries) => {
          if (done) return
          const visible = entries.some((e) => e.isIntersecting && e.intersectionRatio > 0.15)
          if (!visible) return

          const targets = cardRefs.current.filter(Boolean) as HTMLElement[]
          if (!targets.length) return

          inst = animate(targets, {
            opacity: {from: 0, to: 1},
            delay: stagger(120, {from: 'first'}),
            duration: 1500,
            easing: 'easeOutQuad',
            autoplay: true,
            complete: () => {
              // clean inline hints
              targets.forEach((el) => (el.style.willChange = 'auto'))
            },
          })

          done = true
          io.disconnect()
        },
        {root: null, threshold: [0, 0.15, 0.5], rootMargin: '0px 0px -10% 0px'},
      )

      io.observe(grid)
      cleanupIO = () => io.disconnect()
    }

    setup()

    return () => {
      try {
        cleanupIO?.()
        inst?.cancel?.()
      } catch {}
    }
  }, [prefersReduced, skills.length])

  return (
    <section className="relative z-0 w-full p-5 sm:pt-20 px-3 md:px-10 mt-0 bg-blue">
      <h2 className="relative z-10 hp-h2 hp-h2--light hp-h2--left p-5">Erityisosaaminen</h2>

      <ul
        ref={gridRef}
        className="grid gap-2 sm:gap-4 grid-cols-2 m-0 sm:grid-cols-3 lg:grid-cols-5 min-w-0"
      >
        {skills.map((skill, i) => {
          const cardCircles = circles?.[i] ?? []
          return (
            <li key={`${skill.title}-${i}`} className="group pb-0 sm:pb-8">
              <div
                ref={(el) => (cardRefs.current[i] = el)}
                className="
                  relative flex items-center justify-center
                  aspect-[4/5] sm:aspect-[4/5] md:aspect-[4/5]
                  w-full rounded-[.5rem] overflow-hidden
                  text-white font-bold tracking-wide
                  transition-transform duration-300
                  [--blob-scale:.72] sm:[--blob-scale:.88] md:[--blob-scale:1]
                "
              >
                {/* Circles */}
                <div className="absolute inset-0">
                  {cardCircles.map((c, idx) => (
                    <span
                      key={idx}
                      className={`absolute rounded-full will-change-transform ${prefersReduced ? '' : 'anim-floatxy'}`}
                      style={{
                        left: `${c.x}%`,
                        top: `${c.y}%`,
                        width: `calc(var(--blob-scale) * ${c.size}px)`,
                        height: `calc(var(--blob-scale) * ${c.size}px)`,
                        transform: 'translate(-50%, -50%)',
                        background: c.color,
                        filter: `blur(${c.blur}px)`,
                        opacity: c.opacity,
                        ['--dx' as any]: `${c.dx}px`,
                        ['--dy' as any]: `${c.dy}px`,
                        ['--dx2' as any]: `${c.dx2}px`,
                        ['--dy2' as any]: `${c.dy2}px`,
                        ['--dur' as any]: `${c.dur}s`,
                        ['--delay' as any]: `${c.delay}s`,
                      }}
                    />
                  ))}
                </div>

                {/* Label */}
                <span className="font-display z-10 text-[clamp(1.2rem,4vw,1.75rem)] px-2 text-center select-none">
                  {skill.title}
                </span>

                {/* Glossy overlay */}
                <div
                  aria-hidden
                  className="pointer-events-none absolute inset-0 rounded-[.5rem]
                             bg-gradient-to-t from-transparent via-white/5 to-white/10 opacity-40"
                />
              </div>
            </li>
          )
        })}
      </ul>
    </section>
  )
}
