'use client'

import React, {useEffect, useRef, useState} from 'react'

type Skill = {title: string}

export default function SkillsGrid({skills}: {skills: Skill[]}) {
  const [mounted, setMounted] = useState(false)
  const cardRefs = useRef<HTMLDivElement[]>([])

  // Avoid hydration mismatches: render on client only
  useEffect(() => setMounted(true), [])

  useEffect(() => {
    if (!mounted) return

    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

    // crypto-backed RNG
    const rnd = (() => {
      const buf = new Uint32Array(1)
      return () => {
        try {
          crypto.getRandomValues(buf)
          return buf[0] / 0xffffffff
        } catch {
          return Math.random()
        }
      }
    })()
    const r = (min: number, max: number) => min + (max - min) * rnd()

    // HSL helper and higher-contrast palette (teal→blue→slate only)
    const hsl = (h: number, s: number, l: number) => `hsl(${h} ${s}% ${l}%)`

    const makeContrastGradient = (): [string, string, string] => {
      // Only allow hue ranges far from purple (skip 270–320)
      const bands: Array<[number, number]> = [
        [160, 195], // teal/green-cyan
        [195, 225], // blue-cyan
        [225, 260], // blue, but stop before purple fringe
      ]
      const [hmin, hmax] = bands[Math.floor(r(0, bands.length))]
      const baseH = r(hmin, hmax)

      // ↑S and wider L for punchier contrast
      const s1 = r(42, 58),
        s2 = r(36, 52),
        s3 = r(30, 44)
      const l1 = r(60, 70),
        l2 = r(34, 44),
        l3 = r(12, 20)

      const c1 = hsl(baseH + r(-4, 4), s1, l1) // light
      const c2 = hsl(baseH + r(4, 8), s2, l2) // mid
      const c3 = hsl(baseH + r(-24, -16), s3, l3) // dark
      return [c1, c2, c3]
    }

    cardRefs.current.forEach((el, i) => {
      if (!el) return

      // Set colours (use the contrasty generator)
      const [c1, c2, c3] = makeContrastGradient()
      el.style.setProperty('--c1', c1)
      el.style.setProperty('--c2', c2)
      el.style.setProperty('--c3', c3)

      if (prefersReduced) return

      // Animate gradient *values* (angle + mid stop), per-card ranges
      const baseAng = 43 + r(-25, 25) // degrees
      const spanAng = 16 + r(0, 10) // swing
      const baseMid = 46 + r(-6, 6) // %
      const spanMid = 18 + r(0, 8) // a touch wider for contrast play

      el.style.setProperty('--ang-from', `${baseAng - spanAng / 2}deg`)
      el.style.setProperty('--ang-to', `${baseAng + spanAng / 2}deg`)
      el.style.setProperty('--mid-from', `${baseMid - spanMid / 2}%`)
      el.style.setProperty('--mid-to', `${baseMid + spanMid / 2}%`)

      // Duration + stagger
      el.style.setProperty('--grad-dur', `${1.5 + Math.round(r(0, 3))}s`)
      el.style.animationDelay = `${(i * 0.12).toFixed(2)}s`

      // Ensure the animation class is present
      el.classList.add('gradient-animate')
    })
  }, [mounted])

  if (!mounted) return null

  return (
    <section className="w-full py-5 px-6 bg-white">
      <h2 className="font-display font-bold mb-6 text-5xl">Erityisosaaminen</h2>

      <ul className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
        {skills.map((skill, i) => (
          <li key={skill.title} className="group">
            <div
              ref={(el) => {
                if (el) cardRefs.current[i] = el
              }}
              className="relative flex items-center justify-center
                         h-[254px] w-[250px] rounded-[.5rem] overflow-hidden
                         text-white font-bold tracking-wide
                         shadow-[rgba(255,255,255,0.08)_0px_1px_0px_inset,
                                 rgba(0,0,0,0.25)_0px_-10px_20px_inset,
                                 rgba(0,0,0,0.2)_0px_2px_2px,
                                 rgba(0,0,0,0.15)_0px_4px_4px,
                                 rgba(0,0,0,0.1)_0px_8px_8px]
                         transform-gpu transition-transform duration-300
                         group-hover:scale-[1.03] group-hover:shadow-lg"
              style={{
                // Animate the gradient's angle and middle stop
                backgroundImage:
                  'linear-gradient(var(--ang, 43deg), var(--c1, #0b0f19) 0%, var(--c2, #1b2735) var(--mid, 46%), var(--c3, #111827) 100%)',
                backgroundSize: '200% 200%', // stays fixed; values change
              }}
            >
              <span className="font-display z-10 text-3xl px-6">{skill.title}</span>

              {/* Subtle gloss (slightly lighter so the base pops) */}
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 rounded-[.5rem]
                           bg-gradient-to-t from-transparent via-white/8 to-white/20
                           opacity-45 transition-[opacity,filter] duration-300
                           group-hover:opacity-60 group-hover:blur-[0.5px]"
              />
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}
