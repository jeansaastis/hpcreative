import BlogCard from '@/components/BlogCard'
import ContactMe from '@/components/ContactMe'
import {Header} from '@/components/Header'
import HeroSection from '@/components/HeroSection'
import MediaCvSwitcher from '@/components/MediaCvSwitcher'
import {OptimisticSortOrder} from '@/components/OptimisticSortOrder'
import SkillsGrid from '@/components/SkillsGrid'
import TestimonialsSection from '@/components/TestimonialsSection'
import type {HomePageQueryResult} from '@/sanity.types'
import {studioUrl} from '@/sanity/lib/api'
import {resolveHref} from '@/sanity/lib/utils'
import {createDataAttribute} from 'next-sanity'
import {draftMode} from 'next/headers'
import Link from 'next/link'

export interface HomePageProps {
  data: HomePageQueryResult | null
}

export async function HomePage({data}: HomePageProps) {
  // Default to an empty object to allow previews on non-existent documents
  const overview = data?.overview ?? []
  const blogPosts = (data as any)?.blogPosts ?? []
  const title = data?.title ?? ''
  const hero = data?.hero ?? null
  const skills = data?.skills ?? []
  const safeSkills: {title: string}[] = Array.isArray(skills)
    ? skills.map((s: any) => ({title: s?.title ?? ''}))
    : []
  const mediaGallery = data?.mediaGallery ?? []
  const cvSection = data?.cvSection
  const testimonials = data?.testimonials ?? []

  const dataAttribute =
    data?._id && data?._type
      ? createDataAttribute({
          baseUrl: studioUrl,
          id: data._id,
          type: data._type,
        })
      : null

  return (
    <div className="space-y-5">
      {/* Header */}
      {title && <></>}
      {/* Hero */}
      {hero && <HeroSection data={hero} />}
      {/* Skills */}
      {safeSkills.length > 0 && <SkillsGrid skills={safeSkills} />}

      {/* Media / CV Switcher */}
      {(Array.isArray(mediaGallery) && mediaGallery.length > 0) || cvSection ? (
        <MediaCvSwitcher mediaGallery={mediaGallery} cvSection={cvSection} />
      ) : null}

      {/* Blog */}
      <section className="w-full pt-5 sm:pt-20 px-3 md:px-10 bg-white">
        <div className="w-full">
          <h2 id="blogi-heading" className="text-blue hp-h2 hp-h2--light hp-h2--left p-5">
            Blogi — uusimmat
          </h2>

          <div className="mt-8 grid gap-10 lg:grid-cols-12 lg:gap-16">
            {/* Left: latest posts OR fallback */}
            <div className="lg:col-span-7">
              {Array.isArray(blogPosts) && blogPosts.length > 0 ? (
                <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-2 pl-0 ml-0 list-none">
                  {blogPosts.slice(0, 2).map((post: any) => (
                    <li key={post._id || post._key}>
                      <BlogCard post={post} />
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="rounded-[.5rem] border border-black/10 bg-slate-50 p-6 sm:p-8">
                  <h3 className="text-[1.25rem] font-bold text-blue mb-2">
                    Ei blogikirjoituksia vielä
                  </h3>
                  <p className="text-slate-700">
                    Kirjoitan parhaillaan uusia juttuja. Sillä välin voit tutustua osaamiseeni ja
                    ottaa yhteyttä—vastaan mielelläni kysymyksiin.
                  </p>

                  <div className="mt-4 flex flex-wrap gap-3">
                    {/* Jump to sections that already exist on your page */}
                    <Link
                      href="#contact"
                      className="inline-flex items-center rounded-[.5rem] bg-[#11171C] px-4 py-2 text-white hover:opacity-90"
                    >
                      Ota yhteyttä
                    </Link>
                    {safeSkills.length > 0 && (
                      <Link
                        href="#skills"
                        className="inline-flex items-center rounded-[.5rem] border border-black/10 px-4 py-2 text-[#11171C] hover:bg-white"
                      >
                        Erityisosaaminen
                      </Link>
                    )}
                    {(Array.isArray(mediaGallery) && mediaGallery.length > 0) || cvSection ? (
                      <Link
                        href="#media"
                        className="inline-flex items-center rounded-[.5rem] border border-black/10 px-4 py-2 text-[#11171C] hover:bg-white"
                      >
                        Media & CV
                      </Link>
                    ) : null}
                    {data?.linkedinUrl && (
                      <Link
                        href={data.linkedinUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center rounded-[.5rem] border border-black/10 px-4 py-2 text-[#11171C] hover:bg-white"
                      >
                        Seuraa LinkedInissä
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Right: contact form */}
            <div id="contact" className="lg:col-span-5 lg:border-black/10 lg:pl-12">
              <ContactMe />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      {testimonials.length > 0 && <TestimonialsSection testimonials={testimonials} />}
    </div>
  )
}
